from pydantic import BaseModel
from datetime import datetime

class FileMetaBase(BaseModel):
    original_filename: str
    system_filename: str
    file_size_bytes: int
    uploaded_at: datetime

    class Config:
        orm_mode = True
