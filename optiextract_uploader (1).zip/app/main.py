import os
import uuid
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from .database import create_db
from .config import UPLOAD_DIR
from . import crud
from .schemas import FileMetaBase
from typing import List

app = FastAPI(title="OptiExtract - File Uploader")

create_db()

app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "..", "static")), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload-document")
async def upload_document(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    orig = file.filename
    extension = os.path.splitext(orig)[1]
    system_name = f"{uuid.uuid4().hex}{extension}"
    saved_path = os.path.join(UPLOAD_DIR, system_name)

    try:
        with open(saved_path, "wb") as out_file:
            content = await file.read()
            out_file.write(content)
        file_size = os.path.getsize(saved_path)
        record = crud.create_file_meta(original_filename=orig, system_filename=system_name, file_size_bytes=file_size)
        return {"message": "File uploaded successfully", "file": record.system_filename}
    except Exception as e:
        if os.path.exists(saved_path):
            os.remove(saved_path)
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")

@app.get("/files", response_model=List[FileMetaBase])
def get_files():
    return crud.list_file_meta()

@app.get("/download/{system_filename}")
def download_file(system_filename: str):
    path = os.path.join(UPLOAD_DIR, system_filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path, filename=system_filename)
