from .database import SessionLocal
from .models import FileMeta
from datetime import datetime

def create_file_meta(original_filename: str, system_filename: str, file_size_bytes: int):
    db = SessionLocal()
    try:
        fm = FileMeta(
            original_filename=original_filename,
            system_filename=system_filename,
            file_size_bytes=file_size_bytes,
            uploaded_at=datetime.utcnow()
        )
        db.add(fm)
        db.commit()
        db.refresh(fm)
        return fm
    finally:
        db.close()

def list_file_meta():
    db = SessionLocal()
    try:
        return db.query(FileMeta).order_by(FileMeta.uploaded_at.desc()).all()
    finally:
        db.close()
